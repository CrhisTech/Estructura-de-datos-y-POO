# Modulo: mensajeria.py

def Mensaje(msj):
    print('='*50)
    print(msj)
    print('='*50)
